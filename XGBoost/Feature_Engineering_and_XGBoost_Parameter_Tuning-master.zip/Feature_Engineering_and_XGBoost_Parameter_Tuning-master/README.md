### [Data Hackathon 3.X](https://discuss.analyticsvidhya.com/t/data-hackathon-online-3-x-5th-6th-september-2015/2899)的特征工程和Xgboost模型调参例子。
为了便于阅读和交互式学习，这里用的ipython notebook格式，csv文件是此比赛的数据集。欢迎大家下载自己运行。<br>
有问题可以联系[@寒小阳](http://blog.csdn.net/han_xiaoyang)<br>
邮箱：hanxiaoyang.ml@gmail.com
